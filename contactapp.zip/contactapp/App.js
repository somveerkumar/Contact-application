import React from 'react';
import Contact from './components/Contact';
import Card from './components/Card';
import Updatecontact from './components/Updatecontact';
import Deletecontact from './components/Deletecontact';
import {createStackNavigator} from '@react-navigation/stack';
import {NavigationContainer} from '@react-navigation/native';
const Stack=createStackNavigator()
const App=()=>{
  return(
    <NavigationContainer >
   <Stack.Navigator>
     <Stack.Screen  name="Contact App" component={Contact}/>
     <Stack.Screen  name="Add Details" component={Card}/>
     <Stack.Screen  name="Update Contact" component={Updatecontact}/>
     <Stack.Screen  name="delete Contact" component={Deletecontact}/>
   </Stack.Navigator>
   </NavigationContainer>
  )
}
export default App 