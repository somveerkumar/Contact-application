import React,{useState,useEffect} from 'react'
import SQLite from "react-native-sqlite-2";
import {View, Text,TextInput, TouchableOpacity, Alert} from 'react-native'
import { Avatar } from 'react-native-elements';
import * as ImagePicker from 'react-native-image-picker';
const db = SQLite.openDatabase("contacts.db", "1.0", "", 1);
const Card=({navigation})=>{
    const [name,setName]=useState('');
    const [phone,setPhone]=useState('');
    const [email,setEmail]=useState('');
    const [image,setImage]=useState('./somveer.jpeg');
    console.log(name,phone,email)
    const toDB=()=>{
        if(!name){
            alert("Enter the family name ")
            return
        }
        else if(!phone){
            alert("Enter the phone number ")
            return
        }
        else if(!email){
            alert("Enter the email address ")
            return
        }
       
       
        db.transaction(function (txn) {
          // txn.executeSql("DROP TABLE IF EXISTS Contacts", []);
          txn.executeSql(
            "CREATE TABLE IF NOT EXISTS Contacts(user_id INTEGER PRIMARY KEY NOT NULL, Name VARCHAR(30),Phone INTEGER,Email VARCHAR(30))",
            []
          );
         

          txn.executeSql(
            'INSERT INTO Contacts (Name, Phone, Email) VALUES (?,?,?)',
            [name, phone, email],
            (txn, results) => {
              console.log('Results', results.rowsAffected);
              if (results.rowsAffected > 0) {
                Alert.alert(
                  'Success',
                  'contact detail saved Successfully',
                  [
                    {
                      text: 'Ok',
                      onPress: () => navigation.navigate('Contact App'),
                    },
                  ],
                  { cancelable: false }
                );
              } else alert('data  not saved');
            }
          );
        });

        }
        
      const pickImage=()=>{

      
        var options = {
          title: 'Select Image',
          customButtons: [
            {
              name: 'customOptionKey',
              title: 'Choose Photo from Custom Option'
            },
          ],
          storageOptions: {
            skipBackup: true,
            path: 'images',
          },
       };
       ImagePicker.launchImageLibrary(options, response => {
          console.log('Response = ', response);
          if (response.didCancel) {
            console.log('User cancelled image picker');
          } else if (response.error) {
            console.log('ImagePicker Error: ', response.error);
          } else if (response.customButton) {
            console.log(
              'User tapped custom button: ',
              response.customButton
            );
            alert(response.customButton);
          } else {
            setImage(response.uri);
          }
       });}


    return(
        <View style={{justifyContent:'center',alignItems:"center", padding: 10,}}>
            
            <View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            
              <Avatar 
              containerStyle={{marginLeft:20,marginTop:20,borderWidth:2,borderColor:'blue',}}
               size="large"
               rounded
               source={{uri:image}}
               onPress={pickImage}
               activeOpacity={0.7}
              />
           
            </View>
            <TextInput placeholder="Contact Name" 
            textContentType="familyName" 
             style={{height:40,margin:12,borderWidth:0.8,width:200}} onChangeText={setName}
             value={name}
             onChangeText={(value)=>{setName(value)}}
             />

            <TextInput placeholder="Contact Number"
             keyboardType="numeric" style={{height:40,margin:12,borderWidth:0.8,width:200}} 
             value={phone}
             maxLength={10}
             onChangeText={(value)=>setPhone(value)}
             />

            <TextInput placeholder="Contact Email" 
            textContentType="emailAddress" style={{height:40,margin:12,borderWidth:0.8,width:200}} 
            value={email}
            onChangeText={(value)=>setEmail(value)}/>
            </View>

            <TouchableOpacity style={{padding:20,margin:30,backgroundColor:'blue',
            borderRadius:40,width:140,justifyContent:'center',
            alignItems:'center',
            
              }} onPress={toDB}>
                <Text style={{color:'white'}}>SUbmit</Text>
            </TouchableOpacity>
         
        </View>
    )
}
export default Card