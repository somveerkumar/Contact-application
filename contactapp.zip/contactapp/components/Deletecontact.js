import React,{useEffect,useState} from 'react'
import SQLite from "react-native-sqlite-2";
import {View,Text, TouchableOpacity,FlatList, ScrollView, Button, SafeAreaView} from 'react-native'
const db = SQLite.openDatabase("contacts.db", "1.0", "", 1);
const Deletecontact=({route,navigation})=>{
    const [value,setValue]=useState(false);
        const id=route.params.id;
        console.log("deleting id:"+id)
       useEffect( () => {
        alert("callable")
         db.transaction((txn) => {
          txn.executeSql(
            'DELETE FROM  Contacts WHERE user_id=?',
            [id],
            (txn, results) => {
              console.log('Results value', results.rowsAffected);
              console.log(typeof results.rowsAffected)
             
              if (results.rowsAffected > 0) {
                setValue(!value)
                
              } else {
                alert('Please insert a valid User Id');
              }
            }
          );
        });
 
},[])
      

if(value){

    return(
        <View style={{flex:1,padding:10}}>
       <Text>
           deleted
       </Text>
       <TouchableOpacity style={{backgroundColor:'blue',}} onPress={navigation.navigate("Contact App")}>
           <Text style={{color:'white'}}>ok</Text>
       </TouchableOpacity>
        </View>
    )
   
}     
 else{
    return(
        <View style={{justifyContent:'center',alignItems:'center'}}>
            <Text>deleting ...</Text>
        </View>
        )
 }  
}
export default Deletecontact