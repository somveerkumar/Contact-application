import React,{useEffect,useState} from 'react'
import SQLite from "react-native-sqlite-2";
import {View,Text, TouchableOpacity,FlatList, SafeAreaView,Image} from 'react-native'
import { IconButton } from 'react-native-paper'
import { Avatar } from 'react-native-elements';
import * as ImagePicker from 'react-native-image-picker';
const db = SQLite.openDatabase("contacts.db", "1.0", "", 1);
const Contact=({navigation})=>{
        let [flatListItems, setFlatListItems] = useState([]);
        const [image,setImage]=useState('./somveer.jpeg');
        useEffect(() => {
          db.transaction((txn) => {
            txn.executeSql(
              'SELECT * FROM Contacts',
              [],
              (txn, results) => {
                const temp = [];
                for (let i = 0; i < results.rows.length; ++i)
                  temp.push(results.rows.item(i));
                setFlatListItems(temp);
              }
            );
          });
        }, [flatListItems]);
      

     

        const listViewItemSeparator = () => {
          return (
            <View
              style={{
                height: 0.2,
                width: '100%',
                backgroundColor: '#808080'
              }}
            />
          );
        };
      
        const pickImage=()=>{

      
          var options = {
            title: 'Select Image',
            customButtons: [
              {
                name: 'customOptionKey',
                title: 'Choose Photo from Custom Option'
              },
            ],
            storageOptions: {
              skipBackup: true,
              path: 'images',
            },
         };
         ImagePicker.launchImageLibrary(options, response => {
            console.log('Response = ', response);
            if (response.didCancel) {
              console.log('User cancelled image picker');
            } else if (response.error) {
              console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
              console.log(
                'User tapped custom button: ',
                response.customButton
              );
              alert(response.customButton);
            } else {
              setImage(response.uri);
            }
         });}


        const listItemView = (item) => {
         const id=item.user_id
          return (
            <View
              key={item.user_id}
              style={{ backgroundColor: 'white', 
              padding:5,borderWidth:0.5,margin:5,
             
              elevation:20,
              shadowColor:'black'
              }}>
             <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            
             <Avatar 
                  containerStyle={{marginLeft:20,marginTop:20,borderWidth:2,borderColor:'blue',}}
                  size="large"
                  rounded
                  source={{uri:image}}
                  onPress={pickImage}
                  activeOpacity={0.7}
                />
         
          </View>
              <View style={{ flexDirection:'row',}}>
              <View style={{width:250,margin:5}}>
              <Text>Id: {item.user_id}</Text>
              <Text>Name: {item.Name}</Text>
              <Text>Contact: {item.Phone}</Text>
              <Text>Address: {item.Email}</Text>
              </View>
              
              <View style={{justifyContent:'space-evenly',padding:5,marginVertical:10}}>
              <TouchableOpacity>
              <IconButton icon="delete-outline" color={`${Contact==true?"white":'black'}`}  onPress={()=>navigation.navigate("delete Contact",{
                id:item.user_id,
              })}></IconButton>
             </TouchableOpacity>

             <TouchableOpacity>
              <IconButton icon="pencil-outline" color={`${Contact==true?"white":'black'}`}  onPress={()=>navigation.navigate("Update Contact",{
                id:item.user_id,
              })}></IconButton>
             </TouchableOpacity>
             
              </View>
              </View>
            </View>
           
           
          );
        };



       

       

    return(
        <View style={{flex:1}}>
            <View style={{flex:0.95,justifyContent:'center',alignItems:'center',}}>
              <SafeAreaView>
           
            <View >
                <FlatList
                    data={flatListItems}
                    ItemSeparatorComponent={listViewItemSeparator}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item }) => listItemView(item)}
                />
            </View>
       
        </SafeAreaView>
        </View>

        <View style={{flexDirection:'row-reverse',padding:15}}>

            <TouchableOpacity style={{color:'blue',
            backgroundColor:'blue',
            width:70,height:70,
            borderRadius:35,padding:5,
            justifyContent:'center',
            elevation:30,
            shadowColor:'black',
            alignItems:'center'}}
            onPress={()=>{navigation.navigate("Add Details")}} >
                <Text style={{fontSize:25,color:'white'}}>+</Text>
            </TouchableOpacity>
            
            </View>

        </View>
    )
}
export default Contact