import {
  View,
  Alert,
  Text,
  TextInput,TouchableOpacity,
} from 'react-native';
import React,{useState,useEffect} from 'react'
import SQLite from "react-native-sqlite-2";

const db = SQLite.openDatabase("contacts.db", "1.0", "", 1);

const Updatecontact = ({route,navigation }) => {
  const [name,setName]=useState('');
    const [phone,setPhone]=useState('');
    const [email,setEmail]=useState('');
    console.log(name,phone,email)
    const id=JSON.stringify(route.params.id);
  let updateAllStates = (name, phone, email) => {
    setName(name);
    setPhone(JSON.stringify(phone));
    setEmail(email);
  };


  useEffect(() => {
     console.log(id);
     db.transaction((txn) => {
      txn.executeSql(
        'SELECT * FROM Contacts where user_id = ?',
        [id],
        (tx, results) => {
          var len = results.rows.length;
          if (len > 0) {
            let res = results.rows.item(0);
            updateAllStates(
              res.Name,
              res.Phone,
              res.Email
            );
          } else {
            alert('No contact found');
            updateAllStates('', '', '');
          }
        }
      );
    });
  },[])
   
  const updateContact = () => {
    console.log(id, name, phone, email);

    if (!id) {
      alert('Please fill User id');
      return;
    }
    if (!name) {
      alert('Please fill name');
      return;
    }
    if (!phone) {
      alert('Please fill Contact Number');
      return;
    }
    if (!email) {
      alert('Please fill Address');
      return;
    }

    db.transaction((tx) => {
      tx.executeSql(
        'UPDATE Contacts set Name=?, Phone=? , Email=? where user_id=?',
        [name, phone, email, id],
        (tx, results) => {
          console.log('Results', results.rowsAffected);
          if (results.rowsAffected > 0) {
            Alert.alert(
              'Success',
              'User updated successfully',
              [
                {
                  text: 'Ok',
                  onPress: () => navigation.navigate('Contact App'),
                },
              ],
              { cancelable: false }
            );
          } else alert('Updation Failed');
        }
      );
    });
  };

    return(
        <View style={{justifyContent:'center',alignItems:"center", padding: 10,}}>
            
            <View>
            <TextInput placeholder="Contact Name" 
            textContentType="familyName" 
             style={{height:40,margin:12,borderWidth:0.8,width:200}} onChangeText={setName}
             value={name}
             onChangeText={(value)=>{setName(value)}}
             />

            <TextInput placeholder="Contact Number"
             keyboardType="numeric" style={{height:40,margin:12,borderWidth:0.8,width:200}} 
             value={phone}
             maxLength={10}
             onChangeText={(value)=>setPhone(value)}
             />

            <TextInput placeholder="Contact Email" 
            textContentType="emailAddress" style={{height:40,margin:12,borderWidth:0.8,width:200}} 
            value={email}
            onChangeText={(value)=>setEmail(value)}/>
            </View>

            <TouchableOpacity style={{padding:20,margin:30,backgroundColor:'blue',
            borderRadius:40,width:140,justifyContent:'center',
            alignItems:'center',
            
              }} onPress={updateContact}>
                <Text style={{color:'white'}}>SUbmit</Text>
            </TouchableOpacity>
         
        </View>
    )
};

export default Updatecontact;